def main():
    print('Hi from github.')


if __name__ == '__main__':
    main()
